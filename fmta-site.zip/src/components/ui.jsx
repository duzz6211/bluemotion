'use client'

import { useEffect, useRef, useState } from 'react'
import { SPRING_EASING, reducedMotion } from '../spring'
import { img } from '../site'
import cases from '../../data/cases.json'
import programs from '../../data/programs.json'
import gallery from '../../data/gallery.json'

/* ---------- 이미지 (없으면 플레이스홀더) ---------- */
export function Img({ src: first, fallback, alt = '', ...rest }) {
  const [src, setSrc] = useState(first)
  const [bad, setBad] = useState(false)
  const ref = useRef(null)
  const fail = () => (fallback && src !== fallback ? setSrc(fallback) : setBad(true))
  // 하이드레이션 전에 이미 실패한 이미지는 onError가 오지 않으므로 마운트 후 직접 확인
  useEffect(() => {
    const el = ref.current
    if (el && el.complete && el.naturalWidth === 0) fail()
  }, [])
  if (bad) {
    return (
      <div className="ph" role="img" aria-label={alt || '사진 준비 중'}>
        <b>PHOTO</b><span>사진 준비 중</span><span>{src.split('/').pop()}</span>
      </div>
    )
  }
  return <img ref={ref} src={src} alt={alt} loading="lazy" decoding="async" onError={fail} {...rest} />
}

/* ---------- 등장 효과 ---------- */
export function Reveal({ as: Tag = 'div', className = '', children, ...props }) {
  const ref = useRef(null)
  const [shown, setShown] = useState(false)
  useEffect(() => {
    if (!('IntersectionObserver' in window)) { setShown(true); return }
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { setShown(true); io.disconnect() }
    }, { threshold: 0.12 })
    io.observe(ref.current)
    return () => io.disconnect()
  }, [])
  return <Tag ref={ref} className={`reveal${shown ? ' in' : ''} ${className}`.trim()} {...props}>{children}</Tag>
}

export const Todo = ({ children }) => <span className="todo">{children}</span>

/* ---------- 출강 사례 카드 (data/cases.json, 정적) ---------- */
export function Cases({ limit }) {
  const rows = limit ? cases.slice(0, limit) : cases
  return (
    <div className="grid grid-3">
      {rows.map((c) => (
        <Reveal className="card case" key={c.org}>
          <div className="media"><Img src={img(c.image)} alt={`${c.org} ${c.program}`} /></div>
          <span className="tag">{c.program}</span>
          <h3>{c.org}</h3>
          <p>{c.text}</p>
        </Reveal>
      ))}
    </div>
  )
}

/* ---------- 공통 조각 ---------- */
export function PageHero({ eyebrow, title, text }) {
  return (
    <section className="page-hero">
      <div className="container">
        <span className="eyebrow">{eyebrow}</span>
        <h1>{title}</h1>
        {text && <p>{text}</p>}
      </div>
    </section>
  )
}

export function Head({ eyebrow, title, text }) {
  return (
    <Reveal className="section-head">
      <span className="eyebrow">{eyebrow}</span>
      <h2>{title}</h2>
      {text && <p>{text}</p>}
    </Reveal>
  )
}

/* ---------- 프로그램 카드 (data/programs.json) : 대상 / 정원 / 시간 / 특징 ---------- */
export function ProgramCards() {
  return (
    <div className="grid grid-2 program-grid">
      {programs.map((p) => (
        <Reveal as="article" className="card program" id={p.id} key={p.id}>
          <div className="media wide"><Img src={img(p.image)} alt={p.title} /></div>
          <span className="tag">{p.tag}</span>
          <h3>{p.title}</h3>
          <dl className="spec">
            <div><dt>대상</dt><dd>{p.target}</dd></div>
            <div><dt>정원</dt><dd>{p.size}</dd></div>
            <div><dt>시간</dt><dd>{p.time}</dd></div>
          </dl>
          <ul className="checks">{p.points.map((t) => <li key={t}>{t}</li>)}</ul>
          {p.todo && <p><Todo>{p.todo}</Todo></p>}
        </Reveal>
      ))}
    </div>
  )
}

/* ---------- 갤러리 · 영상 (data/gallery.json) ---------- */
export function Gallery({ kind }) {
  const data = gallery
  return (
    <div className="gallery">
      {(data.photos[kind] || []).map((g) => <div className="media" key={g.src}><Img src={img(g.src)} alt={g.alt} /></div>)}
    </div>
  )
}
export function Videos({ kind }) {
  const data = gallery
  return (
    <div className="grid grid-2" style={{ marginTop: 20 }}>
      {(data.videos[kind] || []).map((v) => (
        <div className="video" key={v.title}>
          {v.id
            ? <iframe src={`https://www.youtube-nocookie.com/embed/${encodeURIComponent(v.id)}`} title={v.title} loading="lazy" allow="accelerometer; encrypted-media; picture-in-picture" allowFullScreen />
            : <div className="ph"><b>VIDEO</b><span>{v.title}</span><span>유튜브 영상 ID 입력 필요 (data/gallery.json)</span></div>}
        </div>
      ))}
    </div>
  )
}
